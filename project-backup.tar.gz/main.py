def main():
    print("Hello from python-project-49!")


if __name__ == "__main__":
    main()
