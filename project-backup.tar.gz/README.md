# Brain Games

Github Actions Status: https://github.com/Polva31/python-project-49/actions/workflows/hexlet-check.yml/badge.svg
Quality Gate Status: https://sonarcloud.io/api/project_badges/measure?project=Polva31_python-project-49&metric=alert_status

## Описание
Набор мини-игр для тренировки мозга.

## Установка
make install

## Использование
brain-games

## Игра Калькулятор brain-calc

Игра для вычисления арифметических выражений

## Игра НОД brain-gcd

Игра для нахождения наибольшего общего делителя
